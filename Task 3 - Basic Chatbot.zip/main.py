import nltk
from nltk.chat.util import Chat, reflections

pairs = [
    [
        r"my name is (.*)",
        ["Hello %1! How can I assist you today?", "Nice to meet you, %1! How can I help you today?", "Hi %1! What can I do for you today?"]
    ],
    [
        r"hi|hey|hello",
        ["Hello! How can I assist you today?", "Hey there! What's up?", "Hi! How can I help you today?", "Greetings! How are you today?"]
    ],
    [
        r"what is your name?",
        ["I'm ChatBot, created by Talha. What's your name?", "You can call me ChatBot. And what's your name?", "I'm ChatBot! And you are?"]
    ],
    [
        r"how are you?|are you okay?|are you doing good?",
        ["I'm just a bunch of code, but I'm here to help you!", "I don't have feelings, but I'm here to assist you. How are you?", "I'm functioning perfectly! How about you?"]
    ],
    [
        r"sorry (.*)",
        ["It's okay, no worries at all.", "No problem at all! How can I assist you?", "No worries, %1! How can I help?"]
    ],
    [
        r"i'm (.*) doing good",
        ["That's awesome to hear! How can I help you today?", "Great to hear that you're doing well! What can I do for you?", "Glad to hear that, %1! What's on your mind?"]
    ],
    [
        r"what can you do?",
        ["I can chat with you, answer questions, and provide information. What would you like to talk about?", "I'm here to help you with any questions or information you need. How can I assist?", "I can provide information, chat with you, and help solve problems. What do you need?"]
    ],
    [
        r"how can I create a chatbot?",
        ["You can start by learning Python and use libraries like NLTK or spaCy. Need more details?", "Creating a chatbot involves understanding natural language processing. I can guide you on where to start!", "First, learn some Python basics, then explore libraries like NLTK or spaCy. Would you like some resources?"]
    ],
    [
        r"quit|bye|goodbye",
        ["Goodbye! Have a great day!", "Bye! Take care and have a wonderful day ahead!", "Farewell! Have an awesome day!"]
    ],
    [
        r"what's the weather like?|tell me about the weather?",
        ["I can't check the weather right now, but you can use a weather app for that.", "I'm unable to provide weather updates, but a weather website or app can help you.", "I don't have live weather updates, but checking a weather app should help!"]
    ],
    [
        r"tell me a joke",
        ["Why don't scientists trust atoms? Because they make up everything! Haha!", "Why did the scarecrow win an award? Because he was outstanding in his field! Got any jokes for me?", "What do you call fake spaghetti? An impasta!"]
    ],
    [
        r"what is AI?",
        ["Artificial Intelligence (AI) simulates human intelligence using machines. Curious to learn more?", "AI stands for Artificial Intelligence, enabling machines to imitate intelligent human behavior. Want more details?", "AI is the science of making machines smart. Want to dive deeper into it?"]
    ],
    [
        r"can you help me with programming?",
        ["Absolutely! What programming issue are you facing?", "Sure! What do you need help with in programming?", "I'm here to help! What's your programming question?"]
    ],
    [
        r"tell me something interesting",
        ["Did you know honey never spoils? Pots of honey found in ancient Egyptian tombs are still edible!", "Octopuses have three hearts: two pump blood to the gills, and one pumps it to the rest of the body. Cool, right?", "Did you know bananas are berries, but strawberries aren't?"]
    ],
    [
        r"what is your favorite color?",
        ["I don't have a preference, but I hear blue is quite popular! What's yours?", "As a bot, I don't see colors, but all colors are beautiful in their own way. Do you have a favorite?", "I don't have a favorite color, but I'd love to know yours!"]
    ],
    [
        r"do you like music?",
        ["I don't listen to music, but I can tell you about different genres or artists. What's your favorite genre?", "I don't have the ability to enjoy music, but I can help you find information about it. What do you like to listen to?", "I can't enjoy music, but I know a lot about it. What's your favorite song?"]
    ],
    [
        r"what is (.*)?",
        ["%1 is something you can look up for more detailed information. Want me to help with that?", "I'm not sure about %1, but I can help you find more information on it. Curious to learn more?", "%1 sounds interesting. Let me help you find out more about it!"]
    ],
    [
        r"what's your favorite movie?",
        ["I don't watch movies, but I've heard 'Inception' is mind-blowing!", "I'm a bot, so I don't watch movies, but many people love 'The Matrix'. What's yours?", "I can't watch movies, but I'd love to hear about your favorite!"]
    ],
    [
        r"can you tell me a story?|tell me a story?",
        ["Once upon a time in a land far, far away, there was a curious user who chatted with a friendly bot...", "Sure! There was a young programmer who built an amazing chatbot. The end!", "Of course! There was a coder who asked a bot for help and they created something awesome together!"]
    ],
    [
        r"what's your purpose?",
        ["I'm here to assist you with information and chat with you. How can I help?", "My purpose is to help you with any questions you have and make your day a bit better!", "I'm designed to assist, chat, and provide information. What do you need today?"]
    ],
    [
        r"do you have friends?",
        ["As a bot, I don't have friends, but I enjoy chatting with you!", "I don't have friends, but I'm here to chat with you anytime!", "Bots don't have friends, but I'm happy to be here for you!"]
    ],
    [
        r"what do you think about (.*)?",
        ["I'm not sure about %1, but I'm here to learn more from you!", "I don't have opinions, but I'm interested in what you think about %1.", "I don't have thoughts on %1, but I'd love to hear your perspective!"]
    ],
    [
        r"what's your favorite food?",
        ["I don't eat, but I've heard pizza is quite popular!", "As a bot, I don't eat, but I'd love to know your favorite food!", "I don't have a favorite food, but what do you enjoy eating?"]
    ],
    [
        r"can you recommend a book?",
        ["Sure! 'To Kill a Mockingbird' is a classic. Have you read it?", "How about '1984' by George Orwell? It's thought-provoking!", "I recommend 'The Great Gatsby'. It's a fascinating read!"]
    ],
]

chatbot = Chat(pairs, reflections)

def start_chatbot():
    print("Hi! I am a chatbot created by Talha. How can I help you today?")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["quit", "exit", "bye"]:
            print("Chatbot: Goodbye! Have a great day ahead.")
            break
        response = chatbot.respond(user_input)
        print("Chatbot:", response)

start_chatbot()
