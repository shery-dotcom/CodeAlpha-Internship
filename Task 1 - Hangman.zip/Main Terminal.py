import random

def random_word_selection():
    words_list = ["talha", "python", "programming", "pycharm", "code", "alpha", "game", "machine"]
    return random.choice(words_list)

def current_progress(word, guessed_letters):
    display = ""
    for letter in word:
        if letter in guessed_letters:
            display = display + letter
        else:
            display = display + "_"
    print("Current word:", display)

def play_hangman():
    word = random_word_selection()
    guessed_letters = set()
    incorrect_guesses = 0
    max_incorrect_guesses = 6

    print("Welcome to Hangman!")
    print("You have", max_incorrect_guesses, "incorrect guesses allowed.")

    while incorrect_guesses < max_incorrect_guesses and not all(letter in guessed_letters for letter in word):
        current_progress(word, guessed_letters)
        guess = input("Guess a letter: ").lower()

        if guess in guessed_letters:
            print("You already guessed that letter.")

        elif guess in word:
            guessed_letters.add(guess)
            print("Good guess!")

        else:
            incorrect_guesses = incorrect_guesses + 1
            print("You guessed it wrong.")
            print("Now you have", max_incorrect_guesses - incorrect_guesses, "guesses left.")
            guessed_letters.add(guess)

    if all(letter in guessed_letters for letter in word):
        print("Congratulations!")
        print("You guessed the word right ! ", word)
    else:
        print("Sorry, you've run out of guesses. The word was:", word)

play_hangman()
