import os
import shutil


def organize_files_by_type(directory):
    # List all files in the specified directory
    for filename in os.listdir(directory):
        # Skip directories
        if os.path.isdir(os.path.join(directory, filename)):
            continue

        # Get the file extension
        file_extension = os.path.splitext(filename)[1][1:].lower()  # e.g., 'jpg', 'txt'

        # Create a folder name based on the file extension
        if file_extension:
            folder_name = os.path.join(directory, file_extension)
        else:
            folder_name = os.path.join(directory, 'no_extension')

        # Create the folder if it does not exist
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)

        # Move the file to the appropriate folder
        shutil.move(os.path.join(directory, filename), os.path.join(folder_name, filename))
        print(f'Moved {filename} to {folder_name}')


# Specify the directory to organize
directory_to_organize = r'C:\Users\ahmed\Downloads'  # Replace with the path to your directory

# Organize files
organize_files_by_type(directory_to_organize)
