import requests
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Replace 'your_api_key_here' with your actual Alpha Vantage API key
API_KEY = 'G0ZQMIKEQJUT0MMN.'

# Function to fetch stock price from Alpha Vantage
def get_stock_price(symbol):
    url = f'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={symbol}&interval=1min&apikey={API_KEY}'
    response = requests.get(url)
    data = response.json()
    return data

# Initialize SQLAlchemy
Base = declarative_base()
engine = create_engine('sqlite:///stocks.db')
Session = sessionmaker(bind=engine)
session = Session()

# Define Database Models
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String, nullable=False, unique=True)
    portfolio = relationship('Stock', backref='owner')

class Stock(Base):
    __tablename__ = 'stocks'
    id = Column(Integer, primary_key=True)
    symbol = Column(String, nullable=False)
    quantity = Column(Integer, nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)

Base.metadata.create_all(engine)

# Functions for CRUD Operations
def add_stock(user_id, symbol, quantity):
    new_stock = Stock(symbol=symbol, quantity=quantity, user_id=user_id)
    session.add(new_stock)
    session.commit()

def remove_stock(stock_id):
    stock = session.query(Stock).get(stock_id)
    if stock:
        session.delete(stock)
        session.commit()

def get_portfolio_performance(user_id):
    stocks = session.query(Stock).filter_by(user_id=user_id).all()
    portfolio_value = 0
    for stock in stocks:
        stock_data = get_stock_price(stock.symbol)
        if 'Time Series (1min)' in stock_data:
            latest_data = list(stock_data['Time Series (1min)'].values())[0]
            current_price = float(latest_data['1. open'])
            portfolio_value += current_price * stock.quantity
    return portfolio_value

# Main Program Logic
def main():
    while True:
        print("Stock Portfolio Tracker")
        print("1. Add Stock")
        print("2. Remove Stock")
        print("3. View Portfolio Performance")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            username = input("Enter your username: ")
            user = session.query(User).filter_by(username=username).first()
            if not user:
                user = User(username=username)
                session.add(user)
                session.commit()

            symbol = input("Enter stock symbol: ")
            quantity = int(input("Enter quantity: "))
            add_stock(user.id, symbol, quantity)

        elif choice == '2':
            stock_id = int(input("Enter stock ID to remove: "))
            remove_stock(stock_id)

        elif choice == '3':
            username = input("Enter your username: ")
            user = session.query(User).filter_by(username=username).first()
            if user:
                performance = get_portfolio_performance(user.id)
                print(f"Portfolio Value: ${performance:.2f}")
            else:
                print("User not found.")

        elif choice == '4':
            break

if __name__ == '__main__':
    main()
